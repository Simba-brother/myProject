package com.itheima.mybatis.sqlSession;

public interface SqlSessionFactory {
    SqlSession openSession();
}
