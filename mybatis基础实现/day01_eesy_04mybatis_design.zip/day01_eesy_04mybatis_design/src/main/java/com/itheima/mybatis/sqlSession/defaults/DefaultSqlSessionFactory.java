package com.itheima.mybatis.sqlSession.defaults;

import com.itheima.mybatis.cfg.Configuration;
import com.itheima.mybatis.sqlSession.SqlSession;
import com.itheima.mybatis.sqlSession.SqlSessionFactory;

public class DefaultSqlSessionFactory implements SqlSessionFactory {
    private Configuration cfg;

    public DefaultSqlSessionFactory(Configuration cfg) {
        this.cfg = cfg;
    }

    public SqlSession openSession() {   //工厂生产了session
        return new DefaultSqlSession(cfg);
    }
}
